package com.github.aakira.expandablelayout.uitest

import android.os.Bundle
import android.support.v7.app.AppCompatActivity

class ExpandableRelativeLayoutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_expandable_relative_layout)
    }
}
